
window.onload = function() {
    document.body.classList.add('loaded')
}

function loadGoogleTranslate() {
    new google.translate.TranslateElement(
    "langarea")
    
}
loadGoogleTranslate()


let questionButtons = document.querySelectorAll('.question')
questionButtons.forEach((button, index) => {
    button.addEventListener('click', () => {
        let answers = document.querySelectorAll('.answer')
        answers[index].style.display = 
            answers[index].style.display === 'block' ? 'none' : 'block'
    });
});


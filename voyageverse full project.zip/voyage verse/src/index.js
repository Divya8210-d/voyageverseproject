
import { initializeApp } from 'firebase/app'
import {
    collection, getFirestore, addDoc, setDoc, doc

} from 'firebase/firestore';
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
const firebaseConfig = {
    apiKey: "AIzaSyD5nSqT9ZEF-6HOa4CUcS0mOT5n5OpRqTY",
    authDomain: "travelproject-37d2f.firebaseapp.com",
    projectId: "travelproject-37d2f",
    storageBucket: "travelproject-37d2f.firebasestorage.app",
    messagingSenderId: "1029285326604",
    appId: "1:1029285326604:web:e4cc9fd963cf80f92ba329"
}
initializeApp(firebaseConfig)
const db = getFirestore()
const auth = getAuth()

const signUpForm = document.querySelector('.signup')
const signInForm = document.querySelector('.signin')


signUpForm.addEventListener('submit', (e) => {
    e.preventDefault()

    const email = signUpForm.email.value
    const password = signUpForm.password.value
    createUserWithEmailAndPassword(auth, email, password)



        .then((userCredential) => {
            console.log('registered',)
            const user = userCredential.user
            const colref = doc(db, "users", user.uid)

            // how getDoc and getDoc works
            //how synchronous and asynchronous function are different 
            setDoc(colref,
                {
                    Account: signUpForm.profile.value,
                    email: signUpForm.email.value,
                    password: signUpForm.password.value,
                }
            )

            signUpForm.reset()//reset() and exist() hota hai
            alert("YOU ARE REGISTERED ")
            alert("NOW YOU CAN SIGNIN  IN")
           document.getElementById("container1").style.display ="none"
           document.getElementById("container2").style.display ="block"
           // window.location.href = 'http://127.0.0.1:5501/dist/index.html#down'

        })
        .catch((err) => {
            alert(err.message)
        })
},
)

signInForm.addEventListener('submit', (event) => {
    event.preventDefault()
    const remail = document.getElementById('emailsignin')// agar kisi function ke undar koi variable define kiye hain to wo wahi function tak valid rehta hai
    const rpassword = document.getElementById('passwordsignin')
    const auth = getAuth()  

    signInWithEmailAndPassword(auth, remail.value, rpassword.value)
        .then((userCredential) => {

            const user = userCredential.user;
            localStorage.setItem('loggedInUserId', user.uid);//important
            alert(
                "SUCESSFULLY SIGNED UP"
            )
            alert(

                "CLICK OK TO VIEW YOUR ACCOUNT"
            )

            window.location.href = 'http://127.0.0.1:5501/user%20webpages/useraccount.html';

        })
        .catch((error) => {
            alert(error.message)
        })
})
const signinlink = document.getElementById('signinlink')
const signuplink = document.getElementById('signuplink')

signinlink.addEventListener('click',()=>{
     document.getElementById("container1").style.display ="none"
           document.getElementById("container2").style.display ="block"

})
signuplink.addEventListener('click',()=>{
    document.getElementById("container2").style.display ="none"
          document.getElementById("container1").style.display ="block"

})







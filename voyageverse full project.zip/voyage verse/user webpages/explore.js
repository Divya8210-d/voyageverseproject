window.onload = function() {
    document.body.classList.add('loaded');
};
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-auth.js";
import { getFirestore, doc, setDoc, updateDoc, getDoc ,arrayUnion} from "https://www.gstatic.com/firebasejs/10.11.1/firebase-firestore.js";
//question : why collection is not used doc is used
//question : how many segments these two accepts
const firebaseConfig = {
    apiKey: "AIzaSyD5nSqT9ZEF-6HOa4CUcS0mOT5n5OpRqTY",
    authDomain: "travelproject-37d2f.firebaseapp.com",
    projectId: "travelproject-37d2f",
    storageBucket: "travelproject-37d2f.firebasestorage.app",
    messagingSenderId: "1029285326604",
    appId: "1:1029285326604:web:e4cc9fd963cf80f92ba329"
};
initializeApp(firebaseConfig);

const auth = getAuth();
const db = getFirestore();

const access = "d8BlP133Mzrdmhc86KsokOXa297jzrz5kxjyOFGh8vc";

const form = document.getElementById("searchform");
const input = document.getElementById("input");
const finalresult = document.getElementById("result");
const wishlist = document.getElementById("button2");
const adding = document.getElementById("adding");


let keyword = "";
let page = 1;
let currentImage = null; 
let  currentdescription = null;

async function findimage() {
    keyword = input.value;
    const url = `https://api.unsplash.com/search/photos?page=1&query=${keyword}&per_page=${1}&client_id=${access}`;
    //$ tab lagya jata jab  value humlog usko kisi variable me store kiye ho humlog 
    const response = await fetch(url);
    const data = await response.json();
    const results = data.results;

// question : how map function works
    results.map((result) => {
        const image = document.createElement("img");
        image.className = "image";
        image.src = result.urls.thumb;
        currentImage = result.urls.thumb; 
      
        const description = document.createElement("p");
        description.className = "description";
        currentdescription = result.alt_description;
      
        description.innerHTML ="<b>Description</b>&nbsp&nbsp" + result.alt_description;

        finalresult.style.display = "block";
        finalresult.appendChild(image);
        finalresult.appendChild(description);
    });
}

form.addEventListener("submit", (e) => {
    e.preventDefault();
    adding.style.display ="block"
    page = 1;
    findimage();
    finalresult.innerHTML =""
});
//question : how async function works 
//question: how and promises and then works
let clearbutton = document.getElementById("button1");
function handleClick() {
    history.go(0);
}
clearbutton.addEventListener("click", handleClick);

const loggedInUserId = localStorage.getItem("loggedInUserId");

if (loggedInUserId) {
    const userWishlistDoc = doc(db, "wishlists", loggedInUserId);

    wishlist.addEventListener("click", async () => {
        try {
            await setDoc(userWishlistDoc, {
                id: loggedInUserId,
            
            });
            alert("Wishlist document created successfully! Now you can save your favorite destinations.");
            
        } catch (error) {
            alert("Oops something went wrong!");
        }
    });

    adding.addEventListener("click", async () => {
        
            const wishlistDoc = await getDoc(userWishlistDoc);
            if (!wishlistDoc.exists()) {
                alert("No wishlist found. First, create it!");
                return;
            }
            await updateDoc(userWishlistDoc, {
                imgurl: arrayUnion(currentImage),
                description :arrayUnion(currentdescription),
                destinationplace: arrayUnion(keyword),
                
            });

            alert("Image added to wishlist successfully!");
    
    });
} else {
    alert("Ooops something went wrong");
}




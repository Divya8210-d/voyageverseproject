function loadGoogleTranslate() {
  new google.translate.TranslateElement(
    "langarea")
    
  }
  loadGoogleTranslate()
     
     
        let accountpage = document.getElementById('accountpage')
accountpage.addEventListener('click', () => {
    window.location.href = "http://127.0.0.1:5501/user%20webpages/useraccount.html"
})
window.onload = function () {
    document.body.classList.add('loaded');
};
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-app.js";
import { getFirestore, collection, getDoc, doc, updateDoc, arrayRemove, arrayUnion } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-firestore.js";

const firebaseConfig = {
    apiKey: "AIzaSyD5nSqT9ZEF-6HOa4CUcS0mOT5n5OpRqTY",
    authDomain: "travelproject-37d2f.firebaseapp.com",
    projectId: "travelproject-37d2f",
    storageBucket: "travelproject-37d2f.appspot.com",
    messagingSenderId: "1029285326604",
    appId: "1:1029285326604:web:e4cc9fd963cf80f92ba329"
};
initializeApp(firebaseConfig);

const db = getFirestore();

const loggedInUserId = localStorage.getItem("loggedInUserId");
const userWishlistDoc = doc(db, "wishlists", loggedInUserId);

let getwishlist = document.getElementById("getwishlist");
getwishlist.addEventListener("click", async function getAllImages() {
    const wishlistDoc = await getDoc(userWishlistDoc);

    if (!wishlistDoc.exists()) {
        alert("No wishlist found!");
        return;
    }

    const imgArray = wishlistDoc.data().imgurl;
    const descriptionArray = wishlistDoc.data().description;
    const nameArray = wishlistDoc.data().destinationplace;

    if (imgArray && imgArray.length > 0) {
        const container = document.getElementById("output");
        container.innerHTML = "";

        imgArray.forEach((imgUrl, index) => {
            const boxDiv = document.createElement("div");
            boxDiv.classList.add("box");

            const imageArea = document.createElement("div");
            imageArea.classList.add("image-area");

            const imgElement = document.createElement("img");
            imgElement.src = imgUrl;
            imgElement.alt = "Wishlist Image";
            imageArea.appendChild(imgElement);

            const textArea = document.createElement("div");
            textArea.setAttribute('id', "text-area");

            const locname = document.createElement("p");
            locname.classList.add("weather");
            textArea.appendChild(locname);

            async function getname() {
                const access = "1a3eafc0e1185dcefbc50308c2347368";
                const url = `http://api.openweathermap.org/geo/1.0/direct?q=${nameArray[index]}&limit=1&appid=${access}`;

                try {
                    const response = await fetch(url);
                    const data = await response.json();
                    if (data && data.length > 0) {
                        locname.innerHTML = `<b>${data[0].name}</b>`
                    } else {
                        locname.innerHTML = `<b>Unkonwn place</b>`;
                    }
                } catch (error) {
                    locname.innerHTML = "Error fetching location";
                }
            }
            getname();

            const imgdescription = document.createElement("p");
            imgdescription.id = "description";
            imgdescription.textContent = `${descriptionArray && descriptionArray[index]
                ? descriptionArray[index]
                : "No description available."}`
            textArea.appendChild(imgdescription);

           

            const functionDiv2 = document.createElement("div");
            functionDiv2.classList.add("function");

            const button2_1 = document.createElement("button");
            button2_1.classList.add("button1");
            button2_1.innerHTML = '<i class="fas fa-camera"></i> Uploaded Pictures';
            functionDiv2.appendChild(button2_1);
            button2_1.addEventListener("click", async () => {
                const reviewsModal = document.getElementById("reviewsModal");
                const reviewsContainer = document.getElementById("reviewsContainer");
                reviewsModal.style.display = "block";
                reviewsContainer.innerHTML = "";

                const wishlistData = await getDoc(userWishlistDoc);
                const reviewImages = wishlistData.data().reviewimg || [];
                const destinationImages = reviewImages.filter(review => review.destination === nameArray[index]);

                if (destinationImages.length > 0) {
                    destinationImages.forEach(review => {
                        const imgDiv = document.createElement("div");
                        const img = document.createElement("img");
                        img.src = review.uploadedimg;
                        img.alt = "Uploaded Image";
                        img.style.width = "100%";
                        imgDiv.appendChild(img);
                        reviewsContainer.appendChild(imgDiv);
                    });
                } else {
                    reviewsContainer.textContent = "Nothing have been uploaded yet!!";
                }

                const closeReviewsModal = document.getElementsByClassName("closeReviews")[0];
                closeReviewsModal.onclick = function () {
                    reviewsModal.style.display = "none";
                };

                window.onclick = function (event) {
                    if (event.target == reviewsModal) {
                        reviewsModal.style.display = "none";
                    }
                };
            });







            const button2_2 = document.createElement("button");
            button2_2.classList.add("button2");
            button2_2.innerHTML = ' Upload Pictures';
            functionDiv2.appendChild(button2_2);
            textArea.appendChild(functionDiv2);
            button2_2.addEventListener("click", () => {
                
                if (typeof cloudinary === 'undefined') {
                    alert('Cloudinary script is not loaded properly. Please check the console for errors.');
                    return;
                }

                const cloudName = 'dad2siqxd';  
                const uploadPreset = 'palb2wu9'; 

                const uploadWidget = cloudinary.createUploadWidget(
                    {
                        cloudName: cloudName,
                        uploadPreset: uploadPreset,
                        multiple:true,
                        sources: ['local', 'url', 'camera'],
                        showAdvancedOptions: false,
                        cropping: false,
                        maxFileSize: 5000000, 
                        resourceType: 'image',
                        folder: 'reviewshared',
                    },


                    async function (error, result) {
                        
                        if (error) {
                            console.error("Error during image upload:", error);
                            alert("Image upload failed. Please try again.");
                            return; 
                        }

                        if (result.event === "success") {
                            const uploadedImageUrl = result.info.secure_url;
                    
                            try {
                                await updateDoc(userWishlistDoc, {
                                    reviewimg: arrayUnion({
                                        destination: nameArray[index],
                                        uploadedimg: uploadedImageUrl
                                    })
                                });
                                alert("Image uploaded successfully!");
                            } catch (error) {
                                alert("Failed to update wishlist with the uploaded image.");
                            }
                        }
                    }
                );

                
                try {
                    uploadWidget.open();

                }
                catch (err) {
                    alert("Failed to open the widget. Please try again.");
                }
            });




            const functionDiv4 = document.createElement("div");
            functionDiv4.classList.add("function");
            const commentbutton = document.createElement("button");
            commentbutton.classList.add("button1");
            commentbutton.innerHTML = 'Comment and Give Tips';
            functionDiv4.appendChild(commentbutton);
           

         

            const seeReviewsButton = document.createElement("button");
            seeReviewsButton.classList.add("button2");
            seeReviewsButton.innerHTML = ' See Reviews';
            functionDiv4.appendChild(seeReviewsButton);
            textArea.appendChild(functionDiv4);
           
            const weather = document.createElement("p");
            weather.classList.add("weather");
            textArea.appendChild(weather);
            async function getweather() {
                const access1 = "1a3eafc0e1185dcefbc50308c2347368";
                const url1 = `http://api.openweathermap.org/geo/1.0/direct?q=${nameArray[index]}&limit=1&appid=${access1}`;
                const response1 = await fetch(url1);
                const data1 = await response1.json();

                const latitude = data1[0].lat;
                const longitude = data1[0].lon;
                const access2 = "7ab8977092ece2cc8ffc2cbe63d673f6";
                const url2 = `https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&appid=${access2}&units=metric`;
                const response2 = await fetch(url2);
                const data2 = await response2.json();

                weather.innerHTML = `<b>&nbsp<svg xmlns="http://www.w3.org/2000/svg" width="16" height="18" fill="currentColor" class="bi bi-thermometer-sun" viewBox="0 0 16 16">
  <path d="M5 12.5a1.5 1.5 0 1 1-2-1.415V2.5a.5.5 0 0 1 1 0v8.585A1.5 1.5 0 0 1 5 12.5"/>
  <path d="M1 2.5a2.5 2.5 0 0 1 5 0v7.55a3.5 3.5 0 1 1-5 0zM3.5 1A1.5 1.5 0 0 0 2 2.5v7.987l-.167.15a2.5 2.5 0 1 0 3.333 0L5 10.486V2.5A1.5 1.5 0 0 0 3.5 1m5 1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-1 0v-1a.5.5 0 0 1 .5-.5m4.243 1.757a.5.5 0 0 1 0 .707l-.707.708a.5.5 0 1 1-.708-.708l.708-.707a.5.5 0 0 1 .707 0M8 5.5a.5.5 0 0 1 .5-.5 3 3 0 1 1 0 6 .5.5 0 0 1 0-1 2 2 0 0 0 0-4 .5.5 0 0 1-.5-.5M12.5 8a.5.5 0 0 1 .5-.5h1a.5.5 0 1 1 0 1h-1a.5.5 0 0 1-.5-.5m-1.172 2.828a.5.5 0 0 1 .708 0l.707.708a.5.5 0 0 1-.707.707l-.708-.707a.5.5 0 0 1 0-.708M8.5 12a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-1 0v-1a.5.5 0 0 1 .5-.5"/>
</svg>&nbspTemp:${data2.main.temp}"C<br><svg xmlns="http://www.w3.org/2000/svg" width="16" height="18" fill="currentColor" class="bi bi-thermometer-half" viewBox="0 0 16 16">
  <path d="M9.5 12.5a1.5 1.5 0 1 1-2-1.415V6.5a.5.5 0 0 1 1 0v4.585a1.5 1.5 0 0 1 1 1.415"/>
  <path d="M5.5 2.5a2.5 2.5 0 0 1 5 0v7.55a3.5 3.5 0 1 1-5 0zM8 1a1.5 1.5 0 0 0-1.5 1.5v7.987l-.167.15a2.5 2.5 0 1 0 3.333 0l-.166-.15V2.5A1.5 1.5 0 0 0 8 1"/>
</svg>&nbspPressure:${data2.main.pressure}&nbspPa<br><svg xmlns="http://www.w3.org/2000/svg" width="16" height="18" fill="currentColor" class="bi bi-moisture" viewBox="0 0 16 16">
  <path d="M13.5 0a.5.5 0 0 0 0 1H15v2.75h-.5a.5.5 0 0 0 0 1h.5V7.5h-1.5a.5.5 0 0 0 0 1H15v2.75h-.5a.5.5 0 0 0 0 1h.5V15h-1.5a.5.5 0 0 0 0 1h2a.5.5 0 0 0 .5-.5V.5a.5.5 0 0 0-.5-.5zM7 1.5l.364-.343a.5.5 0 0 0-.728 0l-.002.002-.006.007-.022.023-.08.088a29 29 0 0 0-1.274 1.517c-.769.983-1.714 2.325-2.385 3.727C2.368 7.564 2 8.682 2 9.733 2 12.614 4.212 15 7 15s5-2.386 5-5.267c0-1.05-.368-2.169-.867-3.212-.671-1.402-1.616-2.744-2.385-3.727a29 29 0 0 0-1.354-1.605l-.022-.023-.006-.007-.002-.001zm0 0-.364-.343zm-.016.766L7 2.247l.016.019c.24.274.572.667.944 1.144.611.781 1.32 1.776 1.901 2.827H4.14c.58-1.051 1.29-2.046 1.9-2.827.373-.477.706-.87.945-1.144zM3 9.733c0-.755.244-1.612.638-2.496h6.724c.395.884.638 1.741.638 2.496C11 12.117 9.182 14 7 14s-4-1.883-4-4.267"/>
</svg>&nbspHumidity:${data2.main.humidity}&nbspgm/m^3</b>`;
            }
            getweather();
            const functionDiv3 = document.createElement("div");
            functionDiv3.classList.add("function");
            const removebutton = document.createElement("button");
            removebutton.classList.add("removebutton");
            removebutton.innerHTML = `Remove from wishlist`
            functionDiv3.appendChild(removebutton);
            textArea.appendChild(functionDiv3);


            boxDiv.appendChild(imageArea);
            boxDiv.appendChild(textArea);
            container.appendChild(boxDiv);

            removebutton.addEventListener('click', async () => {
                try {
                    await updateDoc(userWishlistDoc, {
                        imgurl: arrayRemove(imgUrl),
                        description: arrayRemove(descriptionArray[index]),
                        destinationplace: arrayRemove(nameArray[index])
                    });
                    boxDiv.remove();
                    alert("Destination removed successfully");
                } catch (error) {
                    alert("Failed to remove image from wishlist.");
                }
            });

            commentbutton.addEventListener("click", () => {
                const modal = document.getElementById("commentModal");
                modal.style.display = "block";

                const submitComment = document.getElementById("submitComment");
                submitComment.onclick = async function () {
                    const commentInput = document.getElementById("commentInput").value;

                    if (!commentInput) {
                        alert("Please enter a comment.");
                        return;
                    }

                    try {
                        await updateDoc(userWishlistDoc, {
                            comments: arrayUnion({
                                destination: nameArray[index],
                                comment: commentInput
                            })
                        });

                        alert("Comment added successfully.");
                        modal.style.display = "none";
                        document.getElementById("commentInput").value = "";
                    } catch (error) {
                        alert("Failed to add comment.");
                    }
                };

                const closeModal = document.getElementsByClassName("close")[0];
                closeModal.onclick = function () {
                    modal.style.display = "none";
                };

                window.onclick = function (event) {
                    if (event.target == modal) {
                        modal.style.display = "none";
                    }
                };
            });

            seeReviewsButton.addEventListener("click", async () => {
                const reviewsModal = document.getElementById("reviewsModal");
                reviewsModal.style.display = "block";

                const reviewsContainer = document.getElementById("reviewsContainer");
                reviewsContainer.innerHTML = "";

                const wishlistData = await getDoc(userWishlistDoc);
                const comments = wishlistData.data().comments || [];
                const destinationComments = comments.filter(comment => comment.destination === nameArray[index]);

                if (destinationComments.length > 0) {
                    destinationComments.forEach(comment => {
                        const commentDiv = document.createElement("div");
                        commentDiv.textContent = comment.comment;
                        reviewsContainer.appendChild(commentDiv);
                    });
                } else {
                    reviewsContainer.textContent = "No reviews available for this destination.";
                }

                const closeReviewsModal = document.getElementsByClassName("closeReviews")[0];
                closeReviewsModal.onclick = function () {
                    reviewsModal.style.display = "none";
                };

                window.onclick = function (event) {
                    if (event.target == reviewsModal) {
                        reviewsModal.style.display = "none";
                    }
                };
            });
        });
    }
});

const commentModalHTML = `
        <div id="commentModal" class="modal">
            <div class="modal-content">
                <span class="close">&times;</span>
                <textarea id="commentInput" placeholder="Share your experience....."></textarea>
                <button id="submitComment">Submit</button>
            </div>
        </div>`;

document.body.insertAdjacentHTML("beforeend", commentModalHTML);

const reviewsModalHTML = `
        <div id="reviewsModal" class="modal">
            <div class="modal-content">
                <span class="closeReviews">&times;</span>
                <div id="reviewsContainer"></div>
            </div>
        </div>`;

document.body.insertAdjacentHTML("beforeend", reviewsModalHTML);
